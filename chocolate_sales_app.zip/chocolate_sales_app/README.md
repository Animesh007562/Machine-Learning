# 🍫 Chocolate Sales Dashboard + Prediction Model

An interactive analytics dashboard and ML revenue predictor built with
**pandas**, **scikit-learn**, **Plotly**, and **Gradio**.

## What's inside
- `app.py` — the full application (data cleaning, model training, dashboard UI)
- `chocolate_sales.csv` — your uploaded dataset (200,000 orders)
- `requirements.txt` — Python dependencies

## Setup
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Gradio will print a local URL (e.g. `http://127.0.0.1:7860`) — open it in
your browser. Add `demo.launch(share=True)` at the bottom of `app.py` if
you want a temporary public link.

## What it does
1. **Cleans** the raw data: strips `$` from the Amount column, fixes
   negative Boxes_Shipped values, and parses two mixed date formats.
2. **Trains** a `RandomForestRegressor` to predict order `Amount` from
   Product, Country, Channel, Discount %, Price per Box, Marketing Spend,
   and Boxes Shipped (R² ≈ 0.90, MAE ≈ $37 on held-out data). The trained
   model is cached to `sales_model.joblib` so subsequent launches are instant
   — delete that file to force a retrain.
3. **Dashboard tabs**:
   - *Overview*: monthly revenue/order trend, revenue by country, revenue
     by channel
   - *Products & Team*: revenue treemap by product, top salespeople,
     discount-vs-amount scatter
   - *Revenue Predictor*: interactive "what-if" tool — pick a product,
     country, channel, discount, price, marketing spend, and box quantity
     to get a predicted order amount with an uncertainty range, plus a
     feature-importance chart showing what drives the model's predictions

## Using your own data
Point the app at a different file:
```bash
CHOCO_DATA_PATH=/path/to/other_sales.csv python app.py
```
Your CSV needs the same columns: `Product, Country, Channel, Salesperson,
Order_Date, Discount_Pct, Price_per_Box, Marketing_Spend, Boxes_Shipped, Amount`.

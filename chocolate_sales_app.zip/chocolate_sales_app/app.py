"""
Chocolate Sales — Analytics Dashboard + ML Prediction App
===========================================================
Built with: pandas, scikit-learn, Plotly, Gradio

Run locally:
    pip install pandas numpy scikit-learn plotly gradio joblib
    python app.py

This will:
  1. Load & clean chocolate_sales.csv (or your own file — see DATA_PATH below)
  2. Train / load a RandomForest revenue-prediction model
  3. Launch an interactive Gradio dashboard with Plotly charts + a
     "what-if" revenue predictor
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import gradio as gr

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score, mean_absolute_error

# ---------------------------------------------------------------------------
# 1. CONFIG
# ---------------------------------------------------------------------------
DATA_PATH = os.environ.get("CHOCO_DATA_PATH", "chocolate_sales.csv")
MODEL_PATH = "sales_model.joblib"
CAT_FEATURES = ["Product", "Country", "Channel"]
NUM_FEATURES = ["Discount_Pct", "Price_per_Box", "Marketing_Spend", "Boxes_Shipped"]
TARGET = "Amount"

# ---------------------------------------------------------------------------
# 2. LOAD + CLEAN DATA
# ---------------------------------------------------------------------------
def load_and_clean(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, index_col=0)

    # Amount sometimes has a leading "$" and is stored as text
    df["Amount"] = (
        df["Amount"].astype(str).str.replace("$", "", regex=False).astype(float)
    )

    # A handful of Boxes_Shipped rows are negative (data-entry sign errors)
    df["Boxes_Shipped"] = df["Boxes_Shipped"].abs()

    # Order_Date arrives in more than one format (YYYY-MM-DD and DD-MM-YYYY)
    df["Order_Date"] = pd.to_datetime(df["Order_Date"], format="mixed", errors="coerce")
    df = df.dropna(subset=["Order_Date"])

    df["Year"] = df["Order_Date"].dt.year
    df["Month"] = df["Order_Date"].dt.to_period("M").astype(str)
    df["Quarter"] = df["Order_Date"].dt.to_period("Q").astype(str)
    df["DOW"] = df["Order_Date"].dt.day_name()

    return df


print(f"Loading data from {DATA_PATH} ...")
df = load_and_clean(DATA_PATH)
print(f"Loaded {len(df):,} clean rows spanning {df['Order_Date'].min().date()} to {df['Order_Date'].max().date()}")

PRODUCTS = sorted(df["Product"].unique().tolist())
COUNTRIES = sorted(df["Country"].unique().tolist())
CHANNELS = sorted(df["Channel"].unique().tolist())

# ---------------------------------------------------------------------------
# 3. TRAIN (OR LOAD) THE MODEL
# ---------------------------------------------------------------------------
def train_model(df: pd.DataFrame):
    X = df[CAT_FEATURES + NUM_FEATURES]
    y = df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    pre = ColumnTransformer(
        [("cat", OneHotEncoder(handle_unknown="ignore"), CAT_FEATURES)],
        remainder="passthrough",
    )
    model = RandomForestRegressor(
        n_estimators=150, max_depth=12, random_state=42, n_jobs=-1
    )
    pipe = Pipeline([("pre", pre), ("model", model)])
    pipe.fit(X_train, y_train)

    pred = pipe.predict(X_test)
    metrics = {
        "r2": round(r2_score(y_test, pred), 4),
        "mae": round(mean_absolute_error(y_test, pred), 2),
        "n_train": len(X_train),
        "n_test": len(X_test),
    }
    return pipe, metrics


if os.path.exists(MODEL_PATH):
    print("Loading cached model...")
    pipe = joblib.load(MODEL_PATH)
    # quick re-eval so the metrics panel is always accurate for this data file
    _, metrics = train_model(df)
else:
    print("Training model (first run may take ~30-60s on 200k rows)...")
    pipe, metrics = train_model(df)
    joblib.dump(pipe, MODEL_PATH)

print("Model metrics:", metrics)

# ---------------------------------------------------------------------------
# 4. PLOTLY CHART BUILDERS
# ---------------------------------------------------------------------------
TEMPLATE = "plotly_white"
BROWN = "#6b4226"


def fig_kpis_table():
    total_rev = df["Amount"].sum()
    total_orders = len(df)
    total_boxes = df["Boxes_Shipped"].sum()
    aov = df["Amount"].mean()
    return total_rev, total_orders, total_boxes, aov


def fig_monthly_trend():
    m = (
        df.groupby("Month")
        .agg(Revenue=("Amount", "sum"), Orders=("Amount", "count"))
        .reset_index()
        .sort_values("Month")
    )
    fig = go.Figure()
    fig.add_bar(x=m["Month"], y=m["Orders"], name="Orders", yaxis="y2", opacity=0.35, marker_color="#c9a26d")
    fig.add_trace(go.Scatter(x=m["Month"], y=m["Revenue"], name="Revenue", mode="lines+markers",
                              line=dict(color=BROWN, width=3)))
    fig.update_layout(
        title="Monthly Revenue & Order Volume",
        template=TEMPLATE,
        yaxis=dict(title="Revenue ($)"),
        yaxis2=dict(title="Orders", overlaying="y", side="right", showgrid=False),
        xaxis=dict(title="Month", tickangle=-45),
        legend=dict(orientation="h", y=1.1),
        height=430,
    )
    return fig


def fig_country_bar():
    c = df.groupby("Country").agg(Revenue=("Amount", "sum")).reset_index().sort_values("Revenue")
    fig = px.bar(c, x="Revenue", y="Country", orientation="h", template=TEMPLATE,
                 color="Revenue", color_continuous_scale="Brwnyl", title="Revenue by Country")
    fig.update_layout(height=380, coloraxis_showscale=False)
    return fig


def fig_product_treemap():
    p = df.groupby("Product").agg(Revenue=("Amount", "sum"), Orders=("Amount", "count")).reset_index()
    fig = px.treemap(p, path=["Product"], values="Revenue", color="Revenue",
                      color_continuous_scale="Brwnyl", template=TEMPLATE,
                      title="Revenue Share by Product")
    fig.update_layout(height=430)
    return fig


def fig_channel_pie():
    ch = df.groupby("Channel").agg(Revenue=("Amount", "sum")).reset_index()
    fig = px.pie(ch, names="Channel", values="Revenue", hole=0.45, template=TEMPLATE,
                 title="Revenue by Sales Channel",
                 color_discrete_sequence=px.colors.sequential.Brwnyl)
    fig.update_layout(height=380)
    return fig


def fig_salesperson_bar():
    s = (
        df.groupby("Salesperson").agg(Revenue=("Amount", "sum")).reset_index()
        .sort_values("Revenue", ascending=False).head(12)
    )
    fig = px.bar(s.sort_values("Revenue"), x="Revenue", y="Salesperson", orientation="h",
                 template=TEMPLATE, title="Top 12 Salespeople by Revenue",
                 color="Revenue", color_continuous_scale="Brwnyl")
    fig.update_layout(height=430, coloraxis_showscale=False)
    return fig


def fig_discount_scatter():
    sample = df.sample(min(3000, len(df)), random_state=1)
    fig = px.scatter(sample, x="Discount_Pct", y="Amount", color="Channel",
                      opacity=0.5, template=TEMPLATE,
                      title="Discount % vs Order Amount (sampled)")
    fig.update_layout(height=400)
    return fig


def fig_feature_importance():
    ohe = pipe.named_steps["pre"].named_transformers_["cat"]
    cat_names = ohe.get_feature_names_out(CAT_FEATURES).tolist()
    all_names = cat_names + NUM_FEATURES
    importances = pipe.named_steps["model"].feature_importances_
    imp_df = pd.DataFrame({"feature": all_names, "importance": importances})
    imp_df = imp_df.sort_values("importance", ascending=False).head(15)
    fig = px.bar(imp_df.sort_values("importance"), x="importance", y="feature", orientation="h",
                 template=TEMPLATE, title="Top 15 Model Feature Importances",
                 color="importance", color_continuous_scale="Brwnyl")
    fig.update_layout(height=430, coloraxis_showscale=False)
    return fig


# ---------------------------------------------------------------------------
# 5. PREDICTION FUNCTION
# ---------------------------------------------------------------------------
def predict_revenue(product, country, channel, discount_pct, price_per_box,
                     marketing_spend, boxes_shipped):
    row = pd.DataFrame([{
        "Product": product,
        "Country": country,
        "Channel": channel,
        "Discount_Pct": discount_pct,
        "Price_per_Box": price_per_box,
        "Marketing_Spend": marketing_spend,
        "Boxes_Shipped": boxes_shipped,
    }])
    pred = pipe.predict(row)[0]

    # simple uncertainty band using the tree ensemble's spread
    all_tree_preds = np.array([t.predict(pipe.named_steps["pre"].transform(row))[0]
                                for t in pipe.named_steps["model"].estimators_])
    low, high = np.percentile(all_tree_preds, [10, 90])

    fig = go.Figure()
    fig.add_trace(go.Bar(x=["Predicted Amount"], y=[pred], marker_color=BROWN,
                          error_y=dict(type="data", array=[high - pred], arrayminus=[pred - low])))
    fig.update_layout(title="Predicted Order Amount (with 10-90% range)",
                       template=TEMPLATE, height=350, yaxis_title="$ Amount")

    summary = (
        f"### Predicted order amount: **${pred:,.2f}**\n\n"
        f"Likely range (10th-90th percentile across trees): **${low:,.2f} – ${high:,.2f}**\n\n"
        f"Implied revenue per box: **${pred / max(boxes_shipped, 1):,.2f}**"
    )
    return summary, fig


# ---------------------------------------------------------------------------
# 6. GRADIO APP
# ---------------------------------------------------------------------------
total_rev, total_orders, total_boxes, aov = fig_kpis_table()

with gr.Blocks(title="Chocolate Sales Dashboard", theme=gr.themes.Soft(primary_hue="orange")) as demo:
    gr.Markdown("# 🍫 Chocolate Sales — Analytics & Prediction Dashboard")
    gr.Markdown(
        f"**{total_orders:,}** orders · **${total_rev:,.0f}** total revenue · "
        f"**{total_boxes:,.0f}** boxes shipped · **${aov:,.2f}** avg order value"
    )

    with gr.Tabs():
        # ---------------- OVERVIEW TAB ----------------
        with gr.Tab("📊 Overview"):
            gr.Plot(value=fig_monthly_trend())
            with gr.Row():
                gr.Plot(value=fig_country_bar())
                gr.Plot(value=fig_channel_pie())

        # ---------------- PRODUCTS TAB ----------------
        with gr.Tab("🍬 Products & Team"):
            with gr.Row():
                gr.Plot(value=fig_product_treemap())
                gr.Plot(value=fig_salesperson_bar())
            gr.Plot(value=fig_discount_scatter())

        # ---------------- MODEL TAB ----------------
        with gr.Tab("🤖 Revenue Predictor"):
            gr.Markdown(
                f"Model: **RandomForestRegressor** &nbsp;|&nbsp; "
                f"R² = **{metrics['r2']}** &nbsp;|&nbsp; MAE = **${metrics['mae']}** "
                f"(evaluated on a held-out 20% test split of {metrics['n_train']+metrics['n_test']:,} orders)"
            )
            with gr.Row():
                with gr.Column(scale=1):
                    product_in = gr.Dropdown(PRODUCTS, value=PRODUCTS[0], label="Product")
                    country_in = gr.Dropdown(COUNTRIES, value=COUNTRIES[0], label="Country")
                    channel_in = gr.Dropdown(CHANNELS, value=CHANNELS[0], label="Channel")
                    discount_in = gr.Slider(0, 35, value=10, label="Discount %")
                    price_in = gr.Slider(1, 25, value=5, step=0.1, label="Price per Box ($)")
                    spend_in = gr.Slider(0, 800, value=100, label="Marketing Spend ($)")
                    boxes_in = gr.Slider(1, 600, value=100, label="Boxes Shipped")
                    predict_btn = gr.Button("Predict Order Amount", variant="primary")
                with gr.Column(scale=1):
                    pred_output = gr.Markdown()
                    pred_plot = gr.Plot()

            predict_btn.click(
                predict_revenue,
                inputs=[product_in, country_in, channel_in, discount_in, price_in, spend_in, boxes_in],
                outputs=[pred_output, pred_plot],
            )
            gr.Plot(value=fig_feature_importance())

    gr.Markdown(
        "---\n*Data cleaned: `$` stripped from Amount, negative Boxes_Shipped values "
        "corrected, mixed date formats parsed. Model retrains automatically if "
        "`sales_model.joblib` is deleted.*"
    )

if __name__ == "__main__":
    demo.launch()
